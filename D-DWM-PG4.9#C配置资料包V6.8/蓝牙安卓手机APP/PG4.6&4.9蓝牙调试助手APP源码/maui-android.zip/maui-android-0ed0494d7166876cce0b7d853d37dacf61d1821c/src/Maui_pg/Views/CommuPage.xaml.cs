using Maui_pg.ViewModels;

namespace Maui_pg.Views;

public partial class CommuPage : ContentPage
{
    CommuPage_ViewModel View_model;
    public CommuPage(CommuPage_ViewModel vm)  
    {
		InitializeComponent();
        View_model = vm;

        this.BindingContext = vm;
	}

    protected override bool OnBackButtonPressed()
    {
        Task.Run(async () =>
        {
            bool result = await Shell.Current.DisplayAlert("��ʾ", "�˳���Ͽ�����������", "�õ�", "ȡ��");
            if (result)
            {
                //�Ͽ���������
                await View_model.DisconnectFromDeviceAsync_Handler();
                ////������һҳ
                //await Shell.Current.GoToAsync("..", true);  //..
                return base.OnBackButtonPressed();
            }
            else
            {
                return false;
            }
        });
        return base.OnBackButtonPressed();

    }
}